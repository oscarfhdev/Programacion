# 4. Escribir un programa que realice la siguiente operación aritmética


# Aquí simplemente imprimimos el resultado de esta operación matemática, haciendo uso de los parentesis para la prioridad y el "**" para el exponente

print(((3+2)/(2*5))**2)