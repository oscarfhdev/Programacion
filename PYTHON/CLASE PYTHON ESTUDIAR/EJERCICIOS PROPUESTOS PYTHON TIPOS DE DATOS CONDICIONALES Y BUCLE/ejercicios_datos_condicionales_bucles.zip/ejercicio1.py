#     1. Escribir un programa que pregunte el nombre del usuario en la consola y 
#     después de que el usuario lo introduzca muestre por pantalla la cadena ¡Hola <nombre>!, 
#     donde <nombre> es el nombre que el usuario haya introducido.



# Introducimos en la variable nombre el nombre, esto lo hacemos con input
nombre = input("Introduce tu nombre:  ")

# ahora con print imprimimos literalmente el texto entre comillas, y se muestra el contenido de la variable "nombre"
print("¡Hola:",nombre,"!")