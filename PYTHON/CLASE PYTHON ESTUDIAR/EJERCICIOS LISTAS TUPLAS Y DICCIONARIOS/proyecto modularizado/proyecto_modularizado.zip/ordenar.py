def ordenar_ascendente (lista_aleatoria):
    lista_aleatoria_ascendente = sorted(lista_aleatoria)
    print(lista_aleatoria_ascendente)
    return lista_aleatoria_ascendente