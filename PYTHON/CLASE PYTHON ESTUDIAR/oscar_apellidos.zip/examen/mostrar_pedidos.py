def mostrar_pedidos(lista):
    for i in lista:
        print("Estos son los pedidos en la lista: ", i)