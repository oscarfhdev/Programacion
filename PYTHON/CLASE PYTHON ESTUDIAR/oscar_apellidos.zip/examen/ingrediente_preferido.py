def ingrediente_preferido(lista):
    ingredientes = []
    for i in lista:
        for j in i:
            lista.append(j)
        # NO ME DA TIEMPO IBA A COMPROBAR SI ESTABA SINO 1 Y SI ESTÁ MAS 1 LUEGO MAX PARA EL MÁS REPETIDO